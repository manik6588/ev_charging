// A minimal Service Worker to satisfy PWA install requirements
self.addEventListener('fetch', function(event) {
  // Do nothing, let the browser handle network requests normally
});